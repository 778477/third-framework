//
//  AFNetworking.h
//  AFNetworking
//
//  Created by miaoyou.gmy on 2018/7/4.
//  Copyright © 2018年 Kwai. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for AFNetworking.
FOUNDATION_EXPORT double AFNetworkingVersionNumber;

//! Project version string for AFNetworking.
FOUNDATION_EXPORT const unsigned char AFNetworkingVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AFNetworking/PublicHeader.h>


#import <AFNetworking/AFHTTPRequestOperation.h>
#import <AFNetworking/AFHTTPRequestOperationManager.h>
#import <AFNetworking/AFHTTPSessionManager.h>
#import <AFNetworking/AFNetworkReachabilityManager.h>
#import <AFNetworking/AFSecurityPolicy.h>
#import <AFNetworking/AFURLConnectionOperation.h>
#import <AFNetworking/AFURLRequestSerialization.h>
#import <AFNetworking/AFURLResponseSerialization.h>
#import <AFNetworking/AFURLSessionManager.h>
